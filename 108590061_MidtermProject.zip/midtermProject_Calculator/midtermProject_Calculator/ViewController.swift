//
//  ViewController.swift
//  midtermProject_Calculator
//
//  Created by Starvian Wibowo on 4/22/22.
//

import UIKit

class ViewController: UIViewController {

    lazy var theCalc = theCalculator()
    
    @IBOutlet weak var labelRec: UILabel!
    @IBOutlet weak var labelRes: UILabel!
    
    @IBOutlet var clearBtn: UIButton!
    @IBOutlet var equalBtn: UIButton!
    
    @IBOutlet var buttonsOfOperands: [UIButton]!
    @IBOutlet var buttonsOfOperators: [UIButton]!
    @IBOutlet var buttonsofFunctions: [UIButton]!
    
    func layoutTasksBtn() {
        for index in buttonsofFunctions.indices{
            let button = buttonsofFunctions[index]
            button.layer.cornerRadius = button.frame.width / 2
        }
    }
    
    func layoutOptBtn() {
        for index in buttonsOfOperators.indices{
            let button = buttonsOfOperators[index]
            button.layer.cornerRadius = button.frame.width / 2
            button.layer.masksToBounds = true
            button.backgroundColor = UIColor.orange
            button.setTitleColor(UIColor.white, for: .normal)
        }
    }
    
    func layoutOprndBtn() {
        for index in buttonsOfOperands.indices{
            let button = buttonsOfOperands[index]
            if(button.titleLabel?.text == "0") {
                button.layer.cornerRadius = 38
            } else {
                button.layer.cornerRadius = button.frame.width / 2
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutOprndBtn()
        layoutOptBtn()
        layoutTasksBtn()
    }
    
    @IBAction func buttonsPress(_ sender: UIButton){
        for btn in buttonsOfOperators{
            if btn == sender {
                btn.setTitleColor(UIColor.orange, for: .normal)
                btn.backgroundColor = UIColor.white
            }
            else {
                btn.setTitleColor(UIColor.white, for: .normal)
                btn.backgroundColor = UIColor.orange
            }
        }
    }
    
    func modelViewRenew() {
        labelRes.text = theCalc.currOprnd
        labelRec.text = theCalc.records()
    }
    
    @IBAction func optPress(_ sender: UIButton) {
        if let optPress =  sender.titleLabel?.text {
            theCalc.processInputOperator(input: optPress)
        }
        
    }
    
    @IBAction func oprndPress(_ sender: UIButton) {
        if let oprndPress =  sender.titleLabel?.text {
            theCalc.oprndInp(input: oprndPress)
            clearBtn.setTitle("C", for: .normal)
            modelViewRenew()
        }
    }
    
    @IBAction func resetPress(_ sender: Any) {
        if clearBtn.title(for: .normal) == "AC"{
            for btn in buttonsOfOperators{
                btn.setTitleColor(UIColor.white, for: .normal)
                btn.backgroundColor = UIColor.orange
            }
        }
        
        if clearBtn.title(for: .normal) == "C"{
            theCalc.currOprnd = "0"
            if theCalc.recs.isEmpty{
                theCalc.currOprnd = "0"
                theCalc.recs.removeAll()
                theCalc.allClear()
                clearBtn.setTitle("AC", for: .normal)
            }
            else{
                clearBtn.setTitle("AC", for: .normal)
                if labelRes.text == "0"{
                    if labelRec.text != "÷" || labelRec.text != "×" || labelRec.text != "+" || labelRec.text != "-"{
                        theCalc.recs.removeLast()
                    }
                    theCalc.allClear()
                }
            }
        }
        
        else{
            theCalc.allClear()
            clearBtn.setTitle("AC", for: .normal)
        }
        modelViewRenew()
    }
    
    @IBAction func percentagePress(_ sender: Any) {
        theCalc.calcPercent()
        modelViewRenew()
    }

    @IBAction func positiveNegativePress(_ sender: Any) {
        theCalc.signPositiveNegative()
        modelViewRenew()
    }
    
    @IBAction func equalPress(_ sender: UIButton) {
        theCalc.equalInp()
        for btn in buttonsOfOperators{
            btn.setTitleColor(UIColor.white, for: .normal)
            btn.backgroundColor = UIColor.orange
        }
        modelViewRenew()
    }
    
}
