//
//  calcItems.swift
//  midtermProject_Calculator
//
//  Created by Starvian Wibowo on 4/22/22.
//

import Foundation

struct calcItems<Element> {
    
    private var items = [Element]()
    
    mutating func pop() ->Element? {return items.removeLast()}
    mutating func push(item:Element) {items.append(item)}
    
    func count() -> Int! {return items.count}
    func peek() ->Element? {return items.last}
    func empty() -> Bool {return items.isEmpty}
}
