//
//  theCalculator.swift
//  midtermProject_Calculator
//
//  Created by Starvian Wibowo on 4/22/22.
//

import Foundation

class theCalculator {
    
    var resCalc:Decimal! = 0
    var preOptPriority:Int! = 0
    
    var currOpt:String! = ""
    var currOprnd:String! = "0"
    
    var exps = calcItems<String>()
    
    var recs:[String]! = []
    let optPriority:[String: Int]! = ["÷" : 2,"×" : 2, "-" : 1, "+" : 1]
    
    public func oprndInp(input:String) {
        recInsert(items: currOpt)
        exprs()
        optToExpRec()
        
        if(currOprnd == "0" && input != ".") {
            currOprnd = input
        }
        else if (currOprnd.contains(".") && input == ".") {
        }
        else {
            currOprnd = currOprnd + input
        }
    }
    
    private func exprs() {
        if(currOpt != "" && exps.count() >= 3) {
            if(prevCurrOptPriority()) {
                executeCalculation()
                saveOperandToExpression()
            }
        }
    }
    
    private func optToExpRec() {
        if(currOpt != "") {
            preOptPriority = optPriority[currOpt]
            exps.push(item: currOpt)
            currOpt = ""
        }
    }
    
    public func equalInp() {
        currOpt = ""
        currOprnd = zeroOrPointDeletion(operand: currOprnd)
        recInsert(items: currOprnd)
        saveOperandToExpression()
        
        if(exps.count() >= 3) {
            recInsert(items: "=")
            
            while(exps.count() >= 3) {
                executeCalculation()
                exps.push(item: currOprnd)
            }
        } else {
            currOprnd = exps.pop()
            recs.removeLast()
        }
    }
    
    public func processInputOperator(input: String) {
        currOprnd = zeroOrPointDeletion(operand: currOprnd)
        recInsert(items: currOprnd)
        saveOperandToExpression()
        
        currOpt = input
    }
    
    private func saveOperandToExpression() {
        if(currOprnd != "") {
            exps.push(item: currOprnd)
            currOprnd = ""
        }
    }
    
    private func prevCurrOptPriority() -> Bool {
        return preOptPriority >= (optPriority[currOpt]!)
    }
    
    private func recInsert(items: String) {
        if(items != "") {recs.append(items)}
    }
    
    private func executeCalculation() {
        let rightOperand:Decimal! = Decimal(string: exps.pop()!)
        let calOperator = exps.pop()!
        let leftOperand:Decimal! = Decimal(string: exps.pop()!)
        
        switch calOperator {
        case "+":
            addition(a: leftOperand, b: rightOperand)
        case "-":
            subtraction(a: leftOperand, b: rightOperand)
        case "×":
            multiplication(a: leftOperand, b: rightOperand)
        case "÷":
            division(a: leftOperand, b: rightOperand)
        default:
            break
        }
        
        currOprnd = zeroOrPointDeletion(operand: NSDecimalNumber(decimal: resCalc).stringValue)
    }
    
    private func addition(a:Decimal!, b:Decimal!) {resCalc = a + b}
    
    private func subtraction(a:Decimal!, b:Decimal!) {resCalc =  a - b}
    
    private func multiplication(a:Decimal!, b:Decimal!) {resCalc = a * b}
    
    private func division(a:Decimal!, b:Decimal!) {
        
        if(b == 0) {resCalc = 0}
        else {resCalc = a / b}
    }
    
    private func zeroOrPointDeletion(operand: String) -> String {
        
        var formatOperand = operand
        
        if(formatOperand.contains(".")) {
            
            while(formatOperand.last == "0") {formatOperand.removeLast()}
            if(formatOperand.last == ".") {formatOperand.removeLast()}
        }
        
        return formatOperand
    }

    public func records() -> String {return recs.joined(separator: " ")}
        
    public func signPositiveNegative() {
        
        if(currOprnd.prefix(1) == "-") {currOprnd.removeFirst()}
        else {currOprnd = "-" + currOprnd}
    }
    
    public func calcPercent() {
        var operand:Double! = Double(currOprnd)
        operand = operand * 0.01
        currOprnd = String(operand)
    }
    
    public func allClear() {
        
        resCalc = 0
        currOprnd = "0"
        recs.removeAll()
        while(!exps.empty()) {exps.pop()}
    }
    
}
